/*
// CRM <Project4.cpp>
// EE 312 Project 4 submission by
// <Tristan Becnel>
// <tjb3746>
// Slip days used: <0>
// Fall 2021
 */
#include <stdio.h>
#include <assert.h>
#include "MyString.h"
#include "Invent.h"

#define MAX_CUSTOMERS 1000
        Customer customers[MAX_CUSTOMERS];


int num_customers = 0;
static int bottles = 0;
static int rattles = 0;
static int diapers = 0;
static int position = 0;

/* clear the inventory and reset the customer database to empty */
void reset(void) {
    bottles = 0;
    rattles = 0;
    diapers = 0;
        for (int i = 0; i < num_customers; i++) {
            StringDestroy(&customers[i].name);
            customers[i].bottles = 0;
            customers[i].diapers = 0;
            customers[i].rattles = 0;
        }
        num_customers = 0;
        position = 0;
}

void processSummarize() {
    printf("There are %d Bottles %d Diapers and %d Rattles in inventory\n", bottles, diapers, rattles);
    printf("we have had a total of %d different customers\n", num_customers);
    int diaperCustomer = 0;
    int bottleCustomer = 0;
    int rattleCustomer = 0;
    for(int i = 0; i < num_customers; i++){
        if(customers[i].bottles> customers[bottleCustomer].bottles){  // finding which customer has the highest number of each item
            bottleCustomer = i;                                       //set max bottles
        }
        if(customers[i].rattles > customers[rattleCustomer].rattles){
            rattleCustomer = i;                                        //set max rattles
        }
        if(customers[i].diapers > customers[diaperCustomer].diapers){
            diaperCustomer = i;                                       //set max diapers
        }
    }

    if(customers[bottleCustomer].bottles > 0){
        StringPrint(&customers[bottleCustomer].name);
        printf(" has purchased the most Bottles (%d)\n", customers[bottleCustomer].bottles);  //prints out the name of the customer with the most of each item
    }
    if(customers[diaperCustomer].diapers > 0){
        StringPrint(&customers[diaperCustomer].name);
        printf(" has purchased the most Diapers (%d)\n", customers[diaperCustomer].diapers);
    }
    if(customers[rattleCustomer].rattles > 0){
        StringPrint(&customers[rattleCustomer].name);
        printf(" has purchased the most Rattles (%d)\n", customers[rattleCustomer].rattles);
    }

    if (customers[bottleCustomer].bottles <=0)
        printf("no one has purchased any Bottles\n");
    if (customers[diaperCustomer].diapers <= 0) {
        printf("no one has purchased any Diapers\n");
    }
    if (customers[rattleCustomer].rattles <= 0) {
        printf("no one has purchased any Rattles\n");
    }

}

void processPurchase() {
    String Bottles = StringCreate("Bottles");
    String Diapers = StringCreate("Diapers");
    String Rattles = StringCreate("Rattles");
    String customerName;
    String ItemType;								// String that holds the item type
    int itemsPurchased;							// Variable that holds the number of items purchased by the customer

    int flagCustomer = 0;                                     // If the customer is found, this flag is set to true.
    int flagPurchase = 0;                                  	// If the purchase is invalid, this flag is set to true.

    readString(&customerName);                                  // Read the customer's name, ItemType, and ItemsPurchased.
    readString(&ItemType);
    readNum(&itemsPurchased);

    if (StringIsEqualTo(&ItemType, &Bottles))
    {
        if (itemsPurchased > bottles)	                 //Requested bottles exceeds bottles in inventory
        {
            printf("Sorry ");
            StringPrint(&customerName);
            printf(", we only have %d Bottles \n", bottles);
           flagPurchase = 1;
        }
    }
    else if (StringIsEqualTo(&ItemType, &Diapers))
    {
        if (itemsPurchased > diapers)	               //Requested diapers exceeds diapers in inventory
        {
            printf("Sorry ");
            StringPrint(&customerName);
            printf(", we only have %d Diapers \n", diapers);
            flagPurchase = 1;
        }
    }
    else if (StringIsEqualTo(&ItemType, &Rattles))
    {
        if (itemsPurchased > rattles)	             //Requested rattles exceeds rattles in inventory
        {
            printf("Sorry ");
            StringPrint(&customerName);
            printf(", we only have %d Rattles \n", rattles);
            flagPurchase = 1;
        }
    }
    else
    {
       flagPurchase = 1;
    }

    if (flagPurchase == 0)	// Valid Purchase
    {
        int i = 0;
        for (i = 0; i < num_customers; i ++)
        {
            if (StringIsEqualTo(&(customers[i].name), &customerName))
            {
                flagCustomer = 1;
                break;
            }
        }

        if (i != MAX_CUSTOMERS)
        {
            if (flagCustomer == 0)		// Add new customer if true
            {
                customers[i].name = StringDup(&customerName);
                 num_customers++;
            }

            if (StringIsEqualTo(&ItemType, &Bottles))                //Updating store inventory
            {
                bottles = bottles - itemsPurchased;                           //Deduct Bottles
                customers[i].bottles = customers[i].bottles + itemsPurchased;
            }
            else if (StringIsEqualTo(&ItemType, &Diapers))
            {
                diapers = diapers - itemsPurchased;                           //Deduct diapers
                customers[i].diapers = customers[i].diapers + itemsPurchased;
            }
            else if (StringIsEqualTo(&ItemType, &Rattles))
            {
                rattles = rattles - itemsPurchased;                            //Deduct Rattles
                customers[i].rattles = customers[i].rattles +  itemsPurchased;
            }
        }
    }

    StringDestroy(&customerName);
    StringDestroy(&ItemType);
    StringDestroy(&Bottles);
    StringDestroy(&Diapers);
    StringDestroy(&Rattles);
}

void processInventory() {
    String item = StringCreate("Bottles");	// String that holds the word of store items
    String itemType;						        	// String storing the item type
    int itemsToBeAdded;

    readString(&itemType);
    readNum(&itemsToBeAdded);

    if (StringIsEqualTo(&itemType, &item))
    {
        bottles = bottles + itemsToBeAdded;	// Update bottles inventory
    }
    StringDestroy(&item);
    item = StringCreate("Diapers");
     if (StringIsEqualTo(&itemType, &item))
    {
        diapers = diapers +  itemsToBeAdded;	// Update diapers inventory
    }
     StringDestroy(&item);
     item = StringCreate("Rattles");
     if (StringIsEqualTo(&itemType, &item))
    {
        rattles = rattles +  itemsToBeAdded;	// Update rattles inventory
    }
    StringDestroy(&itemType);
    StringDestroy(&item);
}

