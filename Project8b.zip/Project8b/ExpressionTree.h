//
// Created by trist on 11/24/2021.
//
#include "String.h"
#ifndef PROJECT8B_EXPRESSIONTREE_H
#define PROJECT8B_EXPRESSIONTREE_H
class ExpressionTree {
public:
    struct Node{
        String name;
        int value;
        Node* left;
        Node* right;

        Node() {
            name = "";
            value = 0;
        }
        Node(int varValue, String varName) {
            value = varValue;
            name = varName;
        }

    };

    typedef Node* NodePtr;

  //  NodePtr roots[TABLE_SIZE];
private:
    int index;

public:
    Node();
    ~ExpressionTree();

    void add(String name, int value, NodeError* error);

    int get(String name, NodeError* error);

    void set(String name, int value, NodeError* error);

    void next();
    void back();
};
#endif //PROJECT8B_EXPRESSIONTREE_H


