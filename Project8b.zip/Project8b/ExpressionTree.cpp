

#include "ExpressionTree.h"

ExpressionTree::ExpressionTree() {
    index = 0;
    for (int i=0; i<TABLE_SIZE;i++){
        roots[i] = nullptr;
    }
    //capacity = 1;
    //roots = new TableNodePtr[capacity];
}
void deleteRec(ExpressionTree::Node* root) {
    if(root!=nullptr) {
        deleteRec(root->left);
        deleteRec(root->right);

        delete root;
    }
}
ExpressionTree::~ExpressionTree() {
    for(int i = 0; i<TABLE_SIZE;i++) {
        if(roots[i]!= nullptr) {
            deleteRec(roots[i]);
        }
    }
}

void addRec(ExpressionTree::NodePtr &root, String name, int value, NodeError* error) {
    if(root==nullptr) {
        ExpressionTree::NodePtr newNode = new ExpressionTree::Node;
        newNode->name = name;
        newNode->value = value;
        newNode->left = nullptr;
        newNode->right = nullptr;
        root = newNode;
        if(error) *error = NOERROR;

        return;
    }
    if(name < root->name) {
        addRec(root->left, name, value, error);
    }
    else if(name > root->name) {
        addRec(root->right, name, value, error);
    }
    else {
        root->name = name;
        root->value = value;
        if(error) *error = REDEFINED;
    }
}
int getRec(ExpressionTree::NodePtr &root, String name, NodeError* error) {
    if(root==nullptr) {
        if(error) *error = NOTFOUND;
        return 0;
    }
    if(root->name == name) {
        if(error) *error = NOERROR;
        return root->value;
    }
    if(root->name < name) {
        return getRec(root->right, name,error);
    }
    if(root->name > name) {
        return getRec(root->left, name,error);
    }
    return 0;
}

void setRec(ExpressionTree::NodePtr &root, String name, int value, NodeError* error) {
    if(root==nullptr) {
        if(error) *error = NOTFOUND;
        return;
    }
    if(root->name == name) {
        if(error) *error = NOERROR;
        root->value = value;
        return;
    }
    if(root->name < name) {
        return setRec(root->right, name,value,error);
    }
    if(root->name > name) {
        return setRec(root->left, name,value,error);
    }
}



void ExpressionTree::add(String name, int value, NodeError* error) {
    addRec(roots[index], name, value, error);
}
int ExpressionTree::get(String name, NodeError* error) {
    int result = getRec(roots[index], name, error);

    if(*error == NOERROR) {
        return result;
    }
    result = getRec(roots[0], name, error);

    return result;

}
void ExpressionTree::set(String name, int value, NodeError* error) {
    setRec(roots[index], name, value, error);

    if(*error==NOERROR) {
        return;
    }

    setRec(roots[0], name, value, error);
    if(*error!=NOERROR) {
        addRec(roots[0], name, value, nullptr);
    }
}
void ExpressionTree::next(){
    if(index+1<TABLE_SIZE){
        index++;
    }
}

void ExpressionTree::back() {
    if(index>0) {
        deleteRec(roots[index]);
        roots[index] = nullptr;
        index = index-1;
    }
}