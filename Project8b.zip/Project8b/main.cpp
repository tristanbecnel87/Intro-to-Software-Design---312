#include <stdio.h>
#include "Parse.h"
#include "String.h"
#include <stack>

#include <iostream>

int output();

using namespace std;
void run() {
    // Get the next token.
    read_next_token();

    while (next_token_type != END)
    {
        string keyword(next_token());

        if (keyword == "text") {
            read_next_token();
           cout << next_token();
        }
        else if (keyword == "output") {
            cout << output();
        }
        else if (keyword == "var") {
      cout << "rip";
        }
        else if (keyword == "set") {
       cout << "nice";
        }
        else if (keyword == "//") {
            skip_line();
        }
        read_next_token();
    }
}

int output() {
    int op = 0;
    if (next_token_type == SYMBOL) {
       if (next_token()== "+") {
           op = 1;
       }
    }
    if (op = 1) {
    }
}

int main() {
    set_input("test1.blip");
    set_input("test2.blip");
    run();
}