// matrix-multiplication Project2.cpp
// EE 312 Project 2 submission by
// Tristan Becnel
// tjb3746
// Slip days used: 0
// Fall 2021
// Include the contents of this file at the top of every file that you submit, replacing the fields within <>.  Do not keep the <>.
