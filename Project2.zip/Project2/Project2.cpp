// matrix-multiplication Project2.cpp
// EE 312 Project 2 submission by
// Tristan Becnel
// tjb3746
// Slip days used: 0
// Fall 2021
// Include the contents of this file at the top of every file that you submit, replacing the fields within <>.  Do not keep the <>.
#include <stdio.h>
#include <stdint.h>
#include <malloc.h>
#include "MatrixMultiply.h"

void multiplyMatrices(
        double a[],
        const uint32_t a_rows,
        const uint32_t a_cols,
        double b[],
        const uint32_t b_cols,
        double c[]) {
    double total = 0;
    double carry = 0;
    int z = 0;
    // https://en.wikipedia.org/wiki/Row-_and_column-major_order
    for (int i = 0; i < a_rows; i++ ) {
        for (int j = 0; j < b_cols; j++ ) {
            total = 0;
            carry = 0;
            for ( int z = 0; z < a_cols; z++) {
                carry = carry  + a[i * a_cols + z] * b[z * b_cols + j]; //add contents of row till end of row
                total = carry;                                      //total amount of row
            }
            if ( z< a_cols) {
                c[i * b_cols + j] = total; //set c[i] to total
            }

        }
    }

}

double** multiplyMatricesPtr(
        double** a,
        const uint32_t a_rows,
        const uint32_t a_cols,
        double** b,
        const uint32_t b_cols) {
    //malloc operation for a_rows size of stuff
    double** ptrArray = (double**)malloc(a_rows*sizeof(double*)); //allocate memory for ptrArray a_rows

    for (int i  = 0; i < a_rows; i++) {
        double *Column = (double *) malloc(b_cols * sizeof(double *)); //allocate memory for ptrArray b_cols
        ptrArray[i] = Column;
    }
    double aNumber = 0;
    double bNumber = 0;
        for (int i = 0; i < a_rows; i++) {
            for (int g = 0; g < b_cols; g++) {
                ptrArray[i][g] = 0;
                for (int h = 0; h < a_cols; h++ ) {
                    aNumber = a[i][h];
                    bNumber = b[h][g];
                    ptrArray[i][g] = ptrArray[i][g] +  aNumber * bNumber; //times aArray * bArray and add that to ptrArray
                }
            }
        }
    return ptrArray;
}

// https://en.wikipedia.org/wiki/Transpose
double** transposeMatrix(
         double** a,
         const uint32_t a_rows,
         const uint32_t a_cols) {
    double **ptrArray = (double**) malloc(a_cols*sizeof(double*)); //allocate memory for a_cols inside **ptrArray
    for ( int i = 0; i < a_cols; i++) {
        double *Column = (double * ) malloc(a_rows * sizeof(double*)); //allocate memory for a_rows inside ptrArray
        ptrArray[i] = Column;
    }

    for (int i = 0; i < a_cols; i++) {
        for (int g = 0; g < a_rows; g++) {
            ptrArray[i][g] = a[g][i]; //flip rows to columns (transpose)

        }
    }
    return ptrArray;
}
