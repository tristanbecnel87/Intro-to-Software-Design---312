// String ADT <Project3.cpp>
// EE 312 Project 3 submission by
// Tristan Becnel
// tjb3746
// Slip days used: 0
// Fall 2021
// Copy and paste this file at the top of all your submitted source code files.  Do not turn this in by itself.


#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include "UTString.h"

/*
 * Helper macro to find the signature of a UTString
 * Treat this like a function that takes a UTString*
 * Accesses a uint32_t from where the signature should be located
 */
#define CHECK(s) (*(uint32_t*) ((s)->string + (s)->length + 1))

/*
 * Checks if a UTString is valid or not.
 */
bool isOurs(const UTString* s) {  //use it to verify before going into the process
    if (CHECK(s) == SIGNATURE) {
        return true;
    }
    else  {
        return false;
    }
}

/*
 * Allocate a utstring on the heap.
 * Initialize the string correctly by copying src.
 * Return a pointer to the UTString.
 */
UTString* utstrdup(const char* src) {
    UTString* str = (UTString*)malloc(sizeof(UTString)); //allocate memory on the heap
    int i = 0;
    while ( src[i] != '\0') {
        i++;
    }
    char* ch = (char*)malloc(i+5); //+5 to include '\0' and "deadbeef" signature
    i = 0;

    (*str).capacity = i;

    while(src[i] != '\0' ) {
        ch[i] = src[i];
        i++;
    }
    ch[i] = '\0';              //null character
    ch[i+1] = (char) ~ 0xef;   //signature block    char ~ 0xef
    ch[i+2] = (char) ~ 0xbe;
    ch[i+3] = (char) ~ 0xad;
    ch[i+4] = (char) ~ 0xde;

    (*str).string = ch;

    (*str).length = i;    //set length equal to null character

    assert(isOurs(str));     //check that string on the heap is same size as given to us in the parameter of the function.
                             //if assert false then kick out program and error the program. Can comment out assert once done!
    //free(str);            //frees in main so this statement is redundant

    return str;
}

/*
 * Returns the length of s.
 *  s must be a valid UTString.
 */
uint32_t utstrlen(const UTString* s) {
    assert(isOurs(s));           //makes sure UTString is correct. If wrong then return and spit out error to console
    int i = 0;
    char counter;
   // int y = 0;
    while ( i < (*s).capacity ) {                     //loops through s and increments till null
       counter = (*s).string[i];
        if (counter != '\0') {
            i++;
        }
    }
    return i;   //return i
}

/*
 * Append the string suffix to the UTString s.
 *  s must be a valid UTString.
 * Do not allocate any additional storage: only append as many characters
 *  as will actually fit in s.
 * Update the length of s.
 * Return s with the above changes. */
UTString* utstrcat(UTString* s, const char* suffix) {
    assert(isOurs(s));                               //checks UTstring for validity
    int i = (*s).length;
    int y= 0;
    int flag = 0;
    while(i < (*s).capacity)
    {
        if (suffix[y] == '\0') {
            flag = 1;
            break;
        }
        (*s).string[i]=suffix[y];

        y++;
        i++;
    }
    if (flag == 1) {
        (*s).length +=y;            //update length of s
    }
    (*s).string[i]='\0';                //null character
    (*s).string[i+1] = (char) ~ 0xef;   //signature block    char ~ 0xef
    (*s).string[i+2] = (char) ~ 0xbe;
    (*s).string[i+3] = (char) ~ 0xad;
    (*s).string[i+4] = (char) ~ 0xde;
    return s;                               //return s
}

/*
 * Copy src into dst.
 *  dst must be a valid UTString.
 *  src is an ordinary string.
 * Do not allocate any additional storage: only copy as many characters
 *  as will actually fit in dst.
 * Update the length of dst.
 * Return dst with the above changes.
 */
UTString* utstrcpy(UTString* dst, const char* src) {
    assert(isOurs(dst));           //makes sure UTString is correct. If wrong then return and spit out error to console
    int flag = 0;
    int length = strlen(src);
    int i = 0;
    int y = 0;
    while ( i < (*dst).capacity && i<length )  {
        (*dst).string[i] = src[i];       //Assigning src[i] to string[i] till null character '\0' *(src+i) = src[i]
        i++;
        y++;
        flag = 1;
    }
    //Assign signature block to end of String
    if (flag = 1) {
        (*dst).length = i;
    }

    (*dst).string[i] = '\0';              //null character

    (*dst).string[i+1] = (char) ~ 0xef;   //signature block    char ~ 0xef
    (*dst).string[i+2] = (char) ~ 0xbe;
    (*dst).string[i+3] = (char) ~ 0xad;
    (*dst).string[i+4] = (char) ~ 0xde;
    return dst;                               //return dst pointer
}

/*
 * Free all memory associated with the given UTString.
 */
void utstrfree(UTString* self) {
    free((*self).string);    //free string first

    free(self);              //free pointer second. If otherway around then you lose access to the string.
}

/*
 * 1.Make s have at least as much capacity as new_capacity.
 * 2. s must be a valid UTString.
 * 3.If s has enough capacity already, do nothing.
 * 4.If s does not have enough capacity, then allocate enough capacity,
 * 5. copy the old string and the null terminator, free the old string,
 * 6. and update all relevant metadata.
 * 7.Return s with the above changes.
 */
UTString* utstrrealloc(UTString* s, uint32_t new_capacity) {
    assert(isOurs(s));         //2. Check if s is a valid UTString
    char *ch;
    if ((*s).capacity >= new_capacity) {
        return s;              //3. Do nothing
    }
    else {                     //This is the case when capacity is  less than new_capacity
        //memory heap allocation
        ch = (char *) malloc((new_capacity * sizeof(char)) + 5);  //4. Allocate Capacity
        int i = 0;
        while ((*s).string[i] != '\0') {
            ch[i] = (*s).string[i];
            i++;
        }

        free((*s).string);                   //5. copy old string & null terminator & free old string.
        ch[i] = '\0';              //null character
        ch[i + 1] = (char) ~0xef;   //signature block    char ~ 0xef
        ch[i + 2] = (char) ~0xbe;
        ch[i + 3] = (char) ~0xad;
        ch[i + 4] = (char) ~0xde;
        (*s).capacity = new_capacity;
        (*s).string = ch;
        return s;                  //7. Return s with new changes
    }
}
