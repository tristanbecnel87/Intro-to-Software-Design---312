// SpellCheck <Project1.cpp>
// EE 312 Project 1 submission by
// <Tristan Becnel>
// <tjb3746>
// Slip days used: <1>
// Fall 2021
// Copy-paste contents of this file at the top of every .c or .h file that you write or modify.
/*
 * Project1.cpp
 *
 * Name: Tristan Becnel
 * EE312 Summer 2020
 * SuperStrings
 */

#include <stdio.h> // provides declarations for printf and putchar
#include <stdint.h> // provides declarations for int32_t uint32_t and the other (new) standard C types

/*
All of your code must be in this file. Please no #includes other than standard system headers (ie.., stdio.h, stdint.h)

You must write this function (printSuperStrings). Do not change the way the function is declared (i.e., it has
exactly two parameters, each parameter is a standard (mundane) C string (see Instruction).
*/
//int counter = 0;
int superCounter = 0;
char dummyArray[20]={'\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0','\0',};
char superArray[20]={'\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0', '\0'};


void separateStrings( char separate[]) {     //changed char to void testingggg
        int i = 0;
    if (separate[i]  == ' ' && separate[i+1] != '\0') {
        while (separate[i+1] != ' ') {
            dummyArray[i] = separate[i];
            i++;
         //   counter++;
        }
    }
    while (separate[i] != ' ' && separate[i] != '\0') {
        dummyArray[i] = separate[i];
        i++;
       // counter++;
    }


}

void separateSuperStrings( char separate[]) {
    int i = 0;
    int alreadySep = 0;
    if (separate[i] == '\n' && separate[i+1] != '\0') {
        while (separate[i+1] != '\n') {
            superArray[i] = separate[i+1];
            i++;
            superCounter++;
        }
        superCounter++;
        alreadySep++;
    }
    i = 0;
    if (alreadySep  == 0) {
            while (separate[i] != '\n' && separate[i] != '\0') {
                if (separate[i] == ' ') {
                    return;
                }
                superArray[i] = separate[i];
                i++;
                superCounter++;
            }
        }
    }
void separateSuperStringsSpace( char separate[]) {
    int i = 0;
    int alreadySep = 0;
        while (separate[i+1] != ' ' && separate[i+1] != '\0') {
            superArray[i] = separate[i];
            i++;
            superCounter++;
        }
    superArray[i] = separate[i];
        superCounter++;
        alreadySep++;
    i = 0;
}


void printComparedString (int wordOne, int wordTwo) {
    int g = 0;
        if (wordOne == wordTwo) {
            while ( superArray[g] != '\0') {
                printf("%c", superArray[g]);
                g++;
            }
            printf("\n");
        }
};

void printSuperStrings(char targets [], char candidates []) {
       int targetCounter = 0;
       int stringCounter = 0;

    goAgane: separateStrings(&targets[targetCounter]);

    if (candidates[superCounter] == ' ') {
        while (candidates[superCounter] == ' ' ) {
            superCounter++;
        }
        separateSuperStringsSpace(&candidates[superCounter]);
        goto skip;
    }

     separateSuperStrings(&candidates[superCounter]);
skip:
    int lettersCorrect = 0;
    int lettersCorrect2 = 0;
    int totalLetters = 0;
        int g = 0;
    while (dummyArray[g] != '\0') {
        totalLetters++;
        lettersCorrect++;
        g++;
    }
    int i = 0;
    int position = 0;
   // int position2 = 0;
   int counterFor = 0;
    for (g = 0; dummyArray[g] != '\0'; g++)
    {
        for ( int h = 0; superArray[h] != '\0';h++) {
            if (dummyArray[g] == superArray[h+i] ) { //adds i in order to not double count letters in the array
                i++;
                position = h+i;
                lettersCorrect2++;                   //increment to compare to lettersCorrect later on
                break;
            }
        }
    }
    g = 0;

getOut:   printComparedString(lettersCorrect, lettersCorrect2);

    for(i = 0; i < 20; i++)
    {
        dummyArray[i] = '\0';      //empty out targetArray
        superArray[i] = '\0';        //empty out superArray
    }

    if (candidates[superCounter] != '\0') {
        superCounter = superCounter+1;//increment index value
        goto goAgane;                             //repeats printSuperStrings() function
    }

    if (targets[targetCounter] != '\0') {
        while ( targets[targetCounter] != ' ') {                //increment index till next whitespace
            targetCounter = targetCounter + 1;
            if (targets[targetCounter] == '\0') {               //ends program once targetCounter hits end of string
                return;
            }
        }
    targetCounter++;
    //stringCounter = 0;
    superCounter = 0;
        goto goAgane;
    }

}
